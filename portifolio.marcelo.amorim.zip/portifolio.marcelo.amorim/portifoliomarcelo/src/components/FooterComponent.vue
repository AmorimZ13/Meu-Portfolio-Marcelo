<template>
    <footer class="bg-black text-white py-4 px-8 fixed bottom-0 w-full flex justify-center items-center">
        <h1 class="text-lg text-center font-bold text-center">
            2025 Portfólio Marcelo Amorim - ADS
        </h1>
    </footer>
</template>