<template>
  <div style="font-size: 18px; line-height: 1.6;">
    <section style="margin-top: 2em;">
      <h2 style="font-size: 24px; font-weight: bold;">
        Formação e Escolaridade
      </h2>
      <p>
        Estudante de Análise e Desenvolvimento de Sistemas na Universidade Unimar.
      </p>
      <p>Conclusão prevista para 2026.</p>
    </section>

    <!-- Habilidades -->
    <section style="margin-top: 2em;">
      <h2 style="font-size: 24px; font-weight: bold;">Habilidades</h2>
      <ul>
        <li>HTML, CSS e Banco de Dados e Phyton</li>
        <li>Sou comunicativo</li>
        <li>Tenho curso de Pacote de Office</li>
        <li>Vontade de aprender</li>
      </ul>
    </section>

    <!-- Minha Trajetória Até Aqui -->
    <section style="margin-top: 2em;">
      <h2 style="font-size: 24px; font-weight: bold;">Minha Trajetória Até Aqui</h2>
      <p>
        Comecei meus estudos em programação há 2 anos, fui convencido pelo meu irmão e fui gostando de ser Dev apesar de ser apenas um iniciante.
        Já trabalhei em pequenos na faculdade e até já tentei criar um mini jogo de futebol que é minha paixão.
      </p>
    </section>
  </div>
</template>

<script>
export default {
  name: "SeuComponente",
};
</script>
