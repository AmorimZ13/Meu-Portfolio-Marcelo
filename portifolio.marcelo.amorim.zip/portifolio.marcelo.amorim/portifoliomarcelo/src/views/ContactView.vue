<template>
  <div>
    <p class="mb-8">Meus contatos:</p>
    <div class="links">
      <i class="fab fa-linkedin fa-2x mr-3"></i>
      <a href="https://www.linkedin.com/in/marcelo-amorim-a446432ba/" target="_blank">Linkedin</a>
      <i class="fab fa-github fa-2x m-3"></i>
      <a href="https://github.com/AmorimZ13" target="_blank" class="font-color">Github</a>
    </div>

    <form>
      <input type="text" placeholder="Nome" /><br /><br />
      <input type="email" placeholder="Email" /><br /><br />
      <textarea placeholder="Mensagem"></textarea><br /><br />
      <button type="submit">Enviar</button>
    </form>
  </div>
</template>

<script>
export default {
  name: "SeuComponente"
}
</script>
