<template>
  <div class="flex items-center gap-6">
    <img
      src="@/assets/Whatsapp Image 2025-05-19 at 14.39.11.jpeg"
      alt="Foto de Marcelo Amorim"
      class="w-32 h-32 rounded-full object-cover border-4 border-white shadow-lg"
    />

    <div>
      <h1 class="text-4xl font-thin pb-1">Sou Marcelo Amorim</h1>
      <h1 class="font-semibold text-base pb-2">Estudante de Análise e Desenvolvimento de Sistema da Unimar</h1>
      <p class="mb-8">Tenho 20 anos, estou em busca do meu crescimento profissional como Dev.</p>
    </div>
  </div>
</template>
